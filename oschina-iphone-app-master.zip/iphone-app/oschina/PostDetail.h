//
//  PostDetail.h
//  oschina
//
//  Created by wangjun on 12-3-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostDetail : UIViewController
@property (strong, nonatomic) IBOutlet UIWebView *webView;

@end
