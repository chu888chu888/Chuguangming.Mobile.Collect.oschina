//
//  OSCNotice.m
//  oschina
//
//  Created by wangjun on 12-3-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "OSCNotice.h"

@implementation OSCNotice

@synthesize atmeCount;
@synthesize msgCount;
@synthesize reviewCount;
@synthesize newFansCount;

- (id)initWithParameters:(int)natmeCount andMsg:(int)nmsgCount andReview:(int)nreviewCount andFans:(int)nnewFansCount
{
    OSCNotice *notice = [[OSCNotice alloc] init];
    notice.atmeCount = natmeCount;
    notice.msgCount = nmsgCount;
    notice.reviewCount = nreviewCount;
    notice.newFansCount = nnewFansCount;
    return notice;
}

@end
