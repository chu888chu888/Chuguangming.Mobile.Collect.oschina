//
//  FavoriteCell.h
//  oschina
//
//  Created by wangjun on 12-5-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoriteCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;
//长按删除元素用
@property (nonatomic,assign) id delegate;
-(void)initGR;
@end
