//
//  LoadingCell.m
//  oschina
//
//  Created by wangjun on 12-5-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LoadingCell.h"

@implementation LoadingCell

@synthesize lbl;
@synthesize loading;

@end
