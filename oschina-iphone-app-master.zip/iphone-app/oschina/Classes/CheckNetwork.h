//
//  CheckNetwork.h
//  oschina
//
//  Created by wangjun on 12-3-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckNetwork : NSObject

+(BOOL)isExistenceNetwork;

@end
