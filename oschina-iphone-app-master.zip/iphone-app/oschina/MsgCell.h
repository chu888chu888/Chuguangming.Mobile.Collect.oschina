//
//  MsgCell.h
//  oschina
//
//  Created by wangjun on 12-3-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MsgCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *img;
@property (strong, nonatomic) IBOutlet UILabel *lbl_Title;
@property (strong, nonatomic) IBOutlet UITextView *txt_Content;

@property (strong, nonatomic) UIView * myView;

@property (retain, nonatomic) UIView * referView;

//长按删除元素用
@property (nonatomic,assign) id delegate;
-(void)initGR;
@end
