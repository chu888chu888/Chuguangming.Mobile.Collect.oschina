//
//  FriendCell.m
//  oschina
//
//  Created by wangjun on 12-5-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FriendCell.h"

@implementation FriendCell

@synthesize imgPortrait;
@synthesize imgGender;
@synthesize lblName;
@synthesize txtExpertise;

@end
