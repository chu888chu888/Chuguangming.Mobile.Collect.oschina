//
//  MyInfoCell.m
//  oschina
//
//  Created by wangjun on 12-5-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MyInfoCell.h"

@implementation MyInfoCell

@synthesize lblTitle;
@synthesize txtContent;
@synthesize lblContent;

@end
