//
//  SoftwareUnit.m
//  oschina
//
//  Created by wangjun on 12-5-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SoftwareUnit.h"

@implementation SoftwareUnit

@synthesize name;
@synthesize description;
@synthesize url;

- (id)initWithParameters:(NSString *)newName andDescription:(NSString *)newDescription andUrl:(NSString *)newUrl
{
    SoftwareUnit * s = [[SoftwareUnit alloc] init];
    s.name = newName;
    s.description = newDescription;
    s.url = newUrl;
    return s;
}

@end
