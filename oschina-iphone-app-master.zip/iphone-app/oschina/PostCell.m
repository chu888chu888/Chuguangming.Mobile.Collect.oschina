//
//  PostCell.m
//  oschina
//
//  Created by wangjun on 12-3-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "PostCell.h"

@implementation PostCell

@synthesize lbl_AnswerCount;
@synthesize img;
@synthesize lblAuthor;
@synthesize txt_Title;
@synthesize lbl_answer_chinese;

@end
