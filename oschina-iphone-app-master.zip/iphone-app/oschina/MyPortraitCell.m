//
//  MyPortraitCell.m
//  oschina
//
//  Created by wangjun on 12-5-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MyPortraitCell.h"

@implementation MyPortraitCell

@synthesize lblName;

@end
