//
//  UITap.m
//  oschina
//
//  Created by wangjun on 12-3-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UITap.h"

@implementation UITap

@synthesize tag;
@synthesize tagString;

@end
