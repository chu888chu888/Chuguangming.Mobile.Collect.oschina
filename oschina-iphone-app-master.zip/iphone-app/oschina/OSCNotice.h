//
//  OSCNotice.h
//  oschina
//
//  Created by wangjun on 12-3-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSCNotice : NSObject

@property int atmeCount;
@property int msgCount;
@property int reviewCount;
@property int newFansCount;

- (id)initWithParameters:(int)natmeCount andMsg:(int)nmsgCount andReview:(int)nreviewCount andFans:(int)nnewFansCount;

@end
