//
//  CommentRefer.m
//  oschina
//
//  Created by wangjun on 12-4-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CommentRefer.h"

@implementation CommentRefer

@synthesize title;
@synthesize body;

- (id)initWithParamters:(NSString *)ntitle andBody:(NSString *)nbody
{
    CommentRefer *c = [CommentRefer new];
    c.title = ntitle;
    c.body = nbody;
    return c;
}

@end
