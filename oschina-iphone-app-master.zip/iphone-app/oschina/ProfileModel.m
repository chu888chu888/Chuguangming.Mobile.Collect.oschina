//
//  ProfileModel.m
//  oschina
//
//  Created by wangjun on 12-3-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ProfileModel.h"

@implementation ProfileModel

@synthesize tag;
@synthesize key;
@synthesize value;

- (id)initWithParameters:(NSString *)nKey andValue:(NSString *)nValue andTag:(int)nTag
{
    ProfileModel *p = [ProfileModel new];
    p.key = nKey;
    p.value = nValue;
    p.tag = nTag;
    return p;
}

@end
