//
//  ImgRecord.m
//  NextApp
//
//  Created by wangjun on 12-2-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ImgRecord.h"

@implementation ImgRecord
@synthesize img;
@synthesize url;

@end
