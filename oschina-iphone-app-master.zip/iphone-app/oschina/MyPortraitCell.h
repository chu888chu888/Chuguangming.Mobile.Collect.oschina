//
//  MyPortraitCell.h
//  oschina
//
//  Created by wangjun on 12-5-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPortraitCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblName;

@end
