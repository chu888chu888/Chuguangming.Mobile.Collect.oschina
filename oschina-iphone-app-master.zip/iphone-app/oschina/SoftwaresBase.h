//
//  SoftwaresBase.h
//  oschina
//
//  Created by wangjun on 12-5-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SoftwareView.h"
#import "SoftwareTypeView.h"

@interface SoftwaresBase : UIViewController

@property (strong, nonatomic) UISegmentedControl * segment_Title;
@property (strong, nonatomic) SoftwareView * softwareView;
@property (strong, nonatomic) SoftwareTypeView * softwareTypeView;

@end
