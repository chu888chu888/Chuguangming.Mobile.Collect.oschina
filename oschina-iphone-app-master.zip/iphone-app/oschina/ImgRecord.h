//
//  ImgRecord.h
//  NextApp
//
//  Created by wangjun on 12-2-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImgRecord : NSObject

@property (nonatomic,copy) NSString *url;
@property (nonatomic,retain) UIImage *img;

@end
