//
//  SoftwareCatalog.m
//  oschina
//
//  Created by wangjun on 12-5-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SoftwareCatalog.h"

@implementation SoftwareCatalog

@synthesize name;
@synthesize tag;

- (id)initWithParameters:(NSString *)newName andTag:(int)nTag
{
    SoftwareCatalog *s = [[SoftwareCatalog alloc] init];
    s.name = newName;
    s.tag = nTag;
    return s;
}

@end
