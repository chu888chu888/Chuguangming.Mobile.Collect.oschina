﻿/*
 * 原作者: 王俊
 * 
 */

namespace OSChina. Model. AppOnly
{
    /// <summary>
    /// 动弹类型
    /// </summary>
    public enum TweetType
    {
        Latest,
        My,
        Hottest,
    }
}
