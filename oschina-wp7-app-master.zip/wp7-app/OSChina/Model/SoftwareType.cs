﻿/*
 * 原作者: 王俊
 * 
 */

namespace OSChina. Model
{
    public sealed class SoftwareType
    {
        public string name;
        public int tag;
    }
}
